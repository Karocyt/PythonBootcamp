#!/usr/bin/env python3

from distutils.core import setup

setup(name='ai42',
      version='1.0.0',
      description='42AI Bottcamp dummy package',
      author='kevazoul',
      author_email='no@go.co',
      url='https://www.python.org/sigs/distutils-sig/',
      packages=['ai42'],
     )